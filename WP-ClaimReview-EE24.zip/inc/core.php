<?php

require_once EUROCLIMATECHECK_PLUGIN_PATH . '/inc/options.php';
require_once EUROCLIMATECHECK_PLUGIN_PATH . '/inc/core.php';
require_once EUROCLIMATECHECK_PLUGIN_PATH . '/inc/metabox.php';
require_once EUROCLIMATECHECK_PLUGIN_PATH . '/inc/enqueue.php';
require_once EUROCLIMATECHECK_PLUGIN_PATH . '/inc/functions.php';
